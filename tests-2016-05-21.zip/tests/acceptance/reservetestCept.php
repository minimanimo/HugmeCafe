<?php 
$I = new AcceptanceTester($scenario);
$I->wantTo('Test reservation :3');

$I->amOnPage('/');
	$I->wait(3);
	$I->fillField('username', 'JAN');
	$I->wait(1);
	$I->fillField('password', '56070503402');
	$I->wait(1);
	$I->click('Log In');
	$I->wait(1);
	$I->fillField('ReservedDate', '12/01/2017');
	$I->wait(1);
	$I->fillField('ReservedTime', '11:11');
	$I->wait(1);
	$I->fillField('NumberOfPeople', '3');
	$I->wait(1);
	$I->click('Book');
	$I->wait(3);
