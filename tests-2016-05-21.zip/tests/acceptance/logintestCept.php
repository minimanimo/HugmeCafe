<?php 
$I = new AcceptanceTester($scenario);
$I->wantTo('Test login');
$I->amOnPage('/');
	$I->wait(5);
	$I->fillField('username', 'JAN');
	$I->wait(1);
	$I->fillField('password', '56070503402');
	$I->wait(1);
	$I->click('Log In');
	$I->wait(5);
	
