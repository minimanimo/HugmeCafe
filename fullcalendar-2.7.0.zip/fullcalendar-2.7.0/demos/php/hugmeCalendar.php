<?php
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	$conn = new mysqli("127.0.0.1", "root", "", "hugmecafe");
	$result= $connn->query("SELECT FirstName,LastName,PhoneNumber,ReservedDate, ReservedTime FROM Customer,TableReservation");

	$outp = "[";
	while($rs = $result->fetch_array(MYSQLI_ASSOC)) {
		if ($outp != "[") {$outp .= ",";}
		$outp .= '{"FirstName":"' . $rs["FirstName"] .'",';
		$outp .= '"LastName":"' . $rs["LastName"] .'",';
		$outp .= '"PhoneNumber":"' . $rs["PhoneNumber"] .'",';
		$outp .= '"ReservedDate":"' . $rs["ReservedDate"] .'",';
		$outp .= '"ReservedTime":"'. $rs["ReservedTime"] . '"}';
	}



		$outp .="]";
		$conn->close();
		echo($outp);
?>
