/**This index.php is to make a reservation table and link with the login customer/
<?php
     
       $con=mysqli_connect("127.0.0.1","root","","hugmecafe");
if (mysqli_connect_errno()){//echo "Failed to connect to MySQL: " .
mysqli_connect_error();}
    session_start();

    $userName = $_SESSION['user'];

    $_SESSION['cusID'];

    $query = "SELECT * FROM customerlogin WHERE UserName='$userName'";

    $result=mysqli_query($con,$query);
    $row = mysqli_fetch_array($result);
?>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>HugMeCafe' - Free Bootstrap Restaurant Website Template</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="style.css" type="text/css">

<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">

<link href='http://fonts.googleapis.com/css?family=Oxygen:400,300,700' rel='stylesheet' type='text/css'>

<link href='http://fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,900,700,700italic,900italic' rel='stylesheet' type='text/css'>

<link href='http://fonts.googleapis.com/css?family=Niconne' rel='stylesheet' type='text/css'>

</head>



<body>

<header class="headbar">

  <div class="fullbg">

    <div class="row">


      <div class="col-md-2 col-md-offset-5 col-sm-6 col-sm-offset-3 col-xs-1">


        <h1 class="logo">HugMecafe'</h1>


      </div>

      <div class="col-md-10 col-md-offset-1 col-sm-10 col-sm-offset-1 col-xs-2">

        <nav class="navi navbar navbar-default" role="navigation"> 

          <!-- Brand and toggle get grouped for better mobile display -->

          <div class="navbar-header">

            <button type="button" class="navbar-toggle collapsed navb" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>

          </div>

          

          <!-- Collect the nav links, forms, and other content for toggling -->

          <div class="menubox collapse navbar-collapse" id="bs-example-navbar-collapse-1">

            <ul class="nav navbar-nav menu">

              <li><a href="#">Home</a></li>

              <li><a href="#">Food Station</a></li>

              <li><a href="#">Table Reservation</a></li>

              <li><a href="#">Promotion</a></li>

              <li><a href="#">Contact</a></li>
              <li><a href="#" type="button" data-toggle="dropdown">
                WELCOME : <?php echo $row['UserName']; ?>
                <span class="caret"></span>
                <ul class="dropdown-menu">
                  <li><a href="http://localhost/hugmecafe/EventCashier/index.php">Reserved List</a></li>
                  <li id="logout"><a id="logout" name="logout" href="http://localhost/hugmeCafe/tablereservation/logout.php">Log out</a></li>
                </ul>
               
               </a></li> 


            </ul>

          </div>

        </nav>

      </div>

     

    </div>

  </div>

</header>






<div class="container-fluid book section-container">
<div class="fullbg">
  <div class="row">

    <div class="col-md-8 col-md-offset-2 bookhead">

      <h3>Book Your Table</h3>

      <span class="header-text"><font color="#D3D3D3">HugMecafe'</font></span> </div>

    <div class="col-md-8 col-md-offset-2 opening">

      <h4>Opening Hours</h4>

      <p>Sunday to Tuesday 09.00 - 24:00 & Friday and Sunday 08:00 - 03.00</p>

    

    </div>

   

    <div class="col-md-8 col-md-offset-4 forming">

      <form role="form" action="Reservation.php" method="post">

       

        <div class="col-md-6 col-sm-6">

          <div class="form-group">

            <input type="text" class="form-control" name="ReservedDate" id="ReservedDate" placeholder="ReservedDate" value="">

          </div>

          <div class="form-group">
          <input type="text" class="form-control" name="ReservedTime" id="ReservedTime" placeholder="ReservedTime" value="">
          </div>

          <div class="form-group">

            <input type="number" class="form-control" name="NumberOfPeople" id="NumberOfPeople" placeholder="NumberOfPeople" value="" min="1">

          </div>

          <div class="form-group">
            
            <center><button type="submit" class="btn">Book</button></center>

          

        
          </div>

        </div>

      
     

      </form>

    </div>

  </div>
 </div> 

</div>

<div class="container-fluid footer section-container">

  <div class="row">

    <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1">

      <h3>Contact</h3>

      <span class="header-text">HugMecafe'</span> </div>

    <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1">

      <div class="col-md-6 col-sm-6 address">

        <p>KMUTT,</p>

        <p>Street-7 Local Highway,</p>

        <p>Mars - 392022</p>

      </div>

      <div class="col-md-6 col-sm-6 social">

        <ul>

          <li><a href="#"><i class="fa fa-twitter-square"></i></a></li>

          <li><a href="#"><i class="fa fa-facebook-square"></i></a></li>

          <li><a href="#"><i class="fa fa-google-plus-square"></i></a></li>

          <li><a href="#"><i class="fa fa-linkedin-square"></i></a></li>

        </ul>

      </div>

    </div>

  </div>

</div>

<footer class="footerinfo container-fluid">

  <div class="row">

    <div class="col-md-12 col-sm-12">

      <p>&copy; 2015 Designed By <a href="http://www.html5layouts.com">HTML5 Layouts</a> Using <a href="http://www.picjumbo.com">Picjumbo</a> Images. | <a href="http://vectortoons.com/">Get Vector Graphics</a></p>

    </div>

  </div>

</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> 

<script src="js/bootstrap.min.js"></script> 









</body>

</html>

