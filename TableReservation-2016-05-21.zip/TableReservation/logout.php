/*This logout.php is code the customer logout from webapplication*/
<?php

$con=mysqli_connect("127.0.0.1","root","","hugmecafe");
if (mysqli_connect_errno()){//echo "Failed to connect to MySQL: " .
mysqli_connect_error();}
session_start();

$user = $_SESSION['user'];
$cusid = $_SESSION['cusID'];

//echo "<br>"."$user"."<br>";
//echo "<br>"."$cusid"."<br>";


if(!isset($_SESSION['user']))
{

 header("Location:");
}
else if(isset($_SESSION['user'])!="")
{
 // echo "<br>"."$cusid"."<br>";

 session_destroy();
 unset($_SESSION['user']);
 unset($_SESSION['cusID']);

//echo "<script>alert('Please come back to visit us again. We are always at your service'); window.location.href = \"http://127.0.0.1/hugmeCafe/login_hugmecafe/\";</script>";
 header("Location: http://localhost/hugmeCafe/login_hugmecafe");

}


?>