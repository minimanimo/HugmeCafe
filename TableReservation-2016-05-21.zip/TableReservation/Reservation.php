/*This Reservation.php is code reservation table the customer can input Date, time and number of people then sending the information into the database.*/
<?php
$con=mysqli_connect("127.0.0.1","root","","hugmecafe");
if (mysqli_connect_errno()){echo "Failed to connect to MySQL: " . mysqli_connect_error();}
 session_start();

    $CustomerID = $_SESSION['cusID'];
	$ReservedDate= mysqli_real_escape_string($con, $_POST['ReservedDate']);
	$ReservedTime = mysqli_real_escape_string($con, $_POST['ReservedTime']);
	$NumberOfPeople= mysqli_real_escape_string($con, $_POST['NumberOfPeople']);
	

	$sql = "INSERT INTO TableReservation(CustomerID,ReservedDate,ReservedTime,NumberOfPeople)VALUES ('".$CustomerID."', '".$ReservedDate."','".$ReservedTime."','".$NumberOfPeople."');";

	if (!mysqli_query($con,$sql)) {
		die('Error: ' . mysqli_error($con));
	}
	else
	{
 
echo "<script>alert('The data has been added into the database'); window.location.href = \"http://localhost/hugmeCafe/tablereservation/\";</script>";
}
mysqli_close($con);
?>



 
