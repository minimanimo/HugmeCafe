

<?php
$con=mysqli_connect("127.0.0.1","root","","hugmecafe'");
if (mysqli_connect_errno()){echo "Failed to connect to MySQL: " . mysqli_connect_error();}
	//$CustomerID= mysqli_real_escape_string($con, $_POST['1']);
	$ReservedDate= mysqli_real_escape_string($con, $_POST['ReservedDate']);
	$ReservedTime = mysqli_real_escape_string($con, $_POST['ReservedTime']);
	$NumberOfPeople= mysqli_real_escape_string($con, $_POST['NumberOfPeople']);
	

	$sql = "INSERT INTO TableReservation(CustomerID,ReservedDate,ReservedTime,NumberOfPeople)VALUES ('"2"', '".$ReservedDate."','".$ReservedTime."','".$NumberOfPeople."');";

	if (!mysqli_query($con,$sql)) {
		die('Error: ' . mysqli_error($con));
	}

echo "<br>". "Date" . $_POST["ReservedDate"];
echo "<script>alert('The data has been added into the database'); window.location.href = \"http://localhost/TableReservation/index.html?</script>";

// echo "The data has been added into the database.";
mysqli_close($con);
?>
 
