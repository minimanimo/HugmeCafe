<?php
/*This code is to query the data of reservation from every customer to show in the table*/
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	$conn = new mysqli("127.0.0.1", "root", "", "hugmecafe");
	$result= $conn->query("SELECT ReservedID, FirstName, LastName, PhoneNumber, ReservedDate, ReservedTime, NumberOfPeople FROM customer c, tablereservation t WHERE c.CustomerID = t.CustomerID ORDER BY ReservedDate;");

	$outp = "[";
	while($rs = $result->fetch_array(MYSQLI_ASSOC)) {
		if ($outp != "[") {$outp .= ",";}
		$outp .= '{"ReservedID":"' . $rs["ReservedID"] .'",';
		$outp .= '"FirstName":"' . $rs["FirstName"] .'",';
		$outp .= '"LastName":"' . $rs["LastName"] .'",';
		$outp .= '"PhoneNumber":"' . $rs["PhoneNumber"] .'",';
		$outp .= '"ReservedDate":"' . $rs["ReservedDate"] .'",';
		$outp .= '"ReservedTime":"' . $rs["ReservedTime"] .'",';
		$outp .= '"NumberOfPeople":"'. $rs["NumberOfPeople"] . '"}';
	}



		$outp .="]";
		$conn->close();
		echo($outp);
