
<?php

/*This php is to delete a list of reservation from the table.*/

$conn =  new mysqli("127.0.0.1","root","","hugmecafe");
if(mysqli_connect_errno()){
	echo "Fail to connect to MySQL: " .mysqli_connect_error();
}

mysqli_query($conn, "DELETE FROM tablereservation WHERE ReservedID ='".$_GET['ReservedID']."'");
mysqli_close($conn);

echo("Delete data");
?>