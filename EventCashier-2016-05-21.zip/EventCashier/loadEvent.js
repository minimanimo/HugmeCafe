/*This loadEvent.js is to make a table showing a list of reservation*/
loadEvent();

function loadEvent(){
	var xmlhttp = new XMLHttpRequest();
	var url = "http://localhost/hugmecafe/EventCashier/hugmeCalendar.php";
	xmlhttp.onreadystatechange = function(){
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			displayEvent(xmlhttp.responseText);
		}
	}
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
}

function displayEvent(response){
	var arr = JSON.parse(response);
	var i;
	var out=" ";
	for(i=0; i < arr.length; i++){
		out += "<tr><td>" +
		arr[i].ReservedID +
		"</td><td>" +
		arr[i].FirstName +
		"</td><td>" +
		arr[i].LastName +
		"</td><td>" +
		arr[i].ReservedDate +
		"</td><td>" +
		arr[i].ReservedTime +
		"</td><td>" +
		arr[i].NumberOfPeople +
		"</td><td>" +
		"<button onclick=\"deleteEvent('"+arr[i].ReservedID+"')\">Done</button>" +
		"</td></tr>";
	}
	out += "</tbody>";

	document.getElementById("calendarTable").innerHTML = out;
}

function deleteEvent(ReservedID) {
        var xmlhttp = new XMLHttpRequest();
        var url = "http://localhost/hugmecafe/EventCashier/deleteEvent.php?ReservedID="+ReservedID;
        xmlhttp.onreadystatechange=function() {
          if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
          //displayResponse(xmlhttp.responseText);
          loadEvent();
        }
      }
      xmlhttp.open("GET", url, true);
      xmlhttp.send();
    
    }

