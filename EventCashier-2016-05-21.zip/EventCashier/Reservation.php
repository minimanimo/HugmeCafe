
<html>
<head>
	<title>Reservation</title>
</head>

<br> Date : <?php echo $_POST["ReservedDate"]; ?>
<br> Time : <?php echo $_POST["ReservedTime"]; ?>
<br> People : <?php echo $_POST["NumberOfPeople"]; ?>
 
<body>
<?php
$con=mysqli_connect("127.0.0.1","root","","hugmecafe");
if (mysqli_connect_errno()){echo "Failed to connect to MySQL: " . mysqli_connect_error();}
 session_start();

    $CustomerID = $_SESSION['cusID'];
  echo "<br>"."CustomerID : ". $CustomerID . "<br>";

	$ReservedDate= mysqli_real_escape_string($con, $_POST['ReservedDate']);
	$ReservedTime = mysqli_real_escape_string($con, $_POST['ReservedTime']);
	$NumberOfPeople= mysqli_real_escape_string($con, $_POST['NumberOfPeople']);
	

	$sql = "INSERT INTO TableReservation(CustomerID,ReservedDate,ReservedTime,NumberOfPeople)VALUES ('".$CustomerID."', '".$ReservedDate."','".$ReservedTime."','".$NumberOfPeople."');";

	if (!mysqli_query($con,$sql)) {
		die('Error: ' . mysqli_error($con));
	}
	else
	{
 echo "The data has been added into the database.";
}
mysqli_close($con);
?>
</body>
</html>


 
