<?php
     // connect to database
       $con=mysqli_connect("127.0.0.1","root","","hugmecafe");
if (mysqli_connect_errno()){//echo "Failed to connect to MySQL: " .
mysqli_connect_error();}

    session_start();
    // receive value to variables
    $userName=mysql_real_escape_string($_POST['username']); 
    $passWord=mysql_real_escape_string($_POST['password']); 
    //query the data from database 
    $query = "SELECT * FROM customerlogin WHERE UserName='$userName' AND  Password='$passWord'";
    $result=mysqli_query($con,$query); 
    $i = 0 ;
    while ($row = mysqli_fetch_array($result)) {
         $userlogin= $row['UserName'];
         $_SESSION['user'] = $userlogin;
         $cusID = $row['CustomerID'];
         $_SESSION['cusID'] = $cusID;

         $i++ . "<br>";
    }
    // check that the data already exist in database, if data already exist go to next page , if not alert an error
    if(!empty($i))
        {
       header("Location: http://127.0.0.1/hugmeCafe/tablereservation/");
         }

    else {
echo "<script>alert('Incorrect Username or Password'); window.location.href = \"http://127.0.0.1/hugmeCafe/login_hugmecafe/\";</script>";
    }
    

    mysqli_close($con);

?>